import { getStore } from '@netlify/blobs';

const headers = {
  'content-type': 'application/json; charset=utf-8',
  'cache-control': 'no-store'
};

function esc(s) { return String(s || '').replace(/[\u0000-\u001F\u007F]/g, ' ').trim(); }

function toCsv(records) {
  const rows = [
    ['Fecha','Sesión','Participante','Organización','Título','Sector','Tipo','Puntaje global','Nivel','Categoría principal','Top 1','Top 2','Top 3','Diagnóstico']
  ];
  for (const r of records) {
    const e = r.evaluation || {};
    const top = e.topCategories || [];
    rows.push([
      r.createdAt,
      r.sessionCode,
      r.participant,
      r.organization,
      r.title,
      r.sector,
      r.projectType,
      e.globalScore,
      e.level,
      e.submissionGuidance?.primaryCategory,
      top[0] ? `${top[0].code} ${top[0].average}` : '',
      top[1] ? `${top[1].code} ${top[1].average}` : '',
      top[2] ? `${top[2].code} ${top[2].average}` : '',
      e.overallDiagnosis
    ]);
  }
  return rows.map(row => row.map(cell => `"${String(cell ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
}

export const handler = async (event) => {
  if (event.httpMethod !== 'GET') {
    return { statusCode: 405, headers, body: JSON.stringify({ ok:false, error:'Método no permitido.' }) };
  }
  try {
    const params = event.queryStringParameters || {};
    const sessionCode = esc(params.sessionCode || 'GENERAL').toUpperCase().replace(/[^A-Z0-9_-]/g, '') || 'GENERAL';
    const pin = esc(params.pin || '');
    const format = esc(params.format || 'json').toLowerCase();

    if (process.env.ADMIN_PIN && pin !== process.env.ADMIN_PIN) {
      return { statusCode: 401, headers, body: JSON.stringify({ ok:false, error:'PIN de facilitador incorrecto.' }) };
    }

    const store = getStore('wuri-ai-evaluations');
    const list = await store.list({ prefix: `${sessionCode}:` });
    const blobs = list.blobs || [];
    const records = [];
    for (const item of blobs) {
      try {
        const record = await store.get(item.key, { type: 'json' });
        if (record) records.push(record);
      } catch (_) {}
    }
    records.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));

    if (format === 'csv') {
      return {
        statusCode: 200,
        headers: {
          'content-type': 'text/csv; charset=utf-8',
          'content-disposition': `attachment; filename="wuri-${sessionCode}.csv"`,
          'cache-control': 'no-store'
        },
        body: toCsv(records)
      };
    }

    const summary = {
      total: records.length,
      averageScore: records.length ? Number((records.reduce((s,r) => s + Number(r.evaluation?.globalScore || 0), 0) / records.length).toFixed(2)) : 0,
      categories: {}
    };
    for (const r of records) {
      const primary = r.evaluation?.submissionGuidance?.primaryCategory || 'Sin categoría';
      summary.categories[primary] = (summary.categories[primary] || 0) + 1;
    }

    return { statusCode: 200, headers, body: JSON.stringify({ ok:true, sessionCode, summary, records }) };
  } catch (error) {
    return { statusCode: 500, headers, body: JSON.stringify({ ok:false, error:error.message || 'Error inesperado.' }) };
  }
};
