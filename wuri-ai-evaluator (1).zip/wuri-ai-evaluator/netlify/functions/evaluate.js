import { getStore } from '@netlify/blobs';

const CATEGORIES = [
  { code:'A1', axis:'A', axisName:'¿Para quién innovar?', group:'Estudiantes', name:'Student Support and Engagement', meaning:'Apoyo al éxito académico, bienestar, inclusión, diversidad y participación estudiantil.' },
  { code:'A2', axis:'A', axisName:'¿Para quién innovar?', group:'Estudiantes', name:'Student Mobility and Openness', meaning:'Intercambio, colaboración, apertura, redes y movilidad entre instituciones o comunidades.' },
  { code:'A3', axis:'A', axisName:'¿Para quién innovar?', group:'Industria', name:'Industrial Application', meaning:'Aplicación de educación, investigación o conocimiento para generar impacto tangible en industria o sector productivo.' },
  { code:'A4', axis:'A', axisName:'¿Para quién innovar?', group:'Industria', name:'Entrepreneurial Culture & Ecosystem', meaning:'Cultura, mentalidad y ecosistema emprendedor que conecta universidad, estudiantes, profesores, administrativos e industria.' },
  { code:'A5', axis:'A', axisName:'¿Para quién innovar?', group:'Sociedad', name:'Crisis Management', meaning:'Capacidad de responder a crisis ambientales, económicas, sanitarias, sociales o institucionales.' },
  { code:'A6', axis:'A', axisName:'¿Para quién innovar?', group:'Sociedad', name:'Ethics and Integrity', meaning:'Promoción de ética, integridad, valores morales, decisión responsable y ciudadanía global.' },
  { code:'A7', axis:'A', axisName:'¿Para quién innovar?', group:'Comunidad global', name:'Future-Oriented Responses to Global Uncertainty and Geopolitical Risk', meaning:'Anticipación y respuesta a incertidumbre global, riesgos geopolíticos, resiliencia, paz y cooperación.' },
  { code:'A8', axis:'A', axisName:'¿Para quién innovar?', group:'Comunidad global', name:'SDG- and ESG-Based Responses to Past and Present Global Challenges', meaning:'Respuestas basadas en ODS y ESG a desafíos globales de sostenibilidad, inclusión, equidad y gobernanza.' },

  { code:'B1', axis:'B', axisName:'¿Cómo innovar?', group:'Liderazgo', name:'Visionary Leadership', meaning:'Visión clara, inspiradora y estratégica para anticipar desafíos y sostener relevancia.' },
  { code:'B2', axis:'B', axisName:'¿Cómo innovar?', group:'Liderazgo', name:'Empowerment-Based Management', meaning:'Gestión que empodera, cede control, fomenta colaboración, confianza y participación de actores diversos.' },
  { code:'B3', axis:'B', axisName:'¿Cómo innovar?', group:'Entorno', name:'Digital and AI Transformation in Strategy and Management', meaning:'Transformación digital e IA en estrategia, operaciones, toma de decisiones, aprendizaje, investigación y administración.' },
  { code:'B4', axis:'B', axisName:'¿Cómo innovar?', group:'Entorno', name:'Culture/Values', meaning:'Cultura innovadora, enfoque centrado en usuarios, valores sociales, creatividad y mejora continua.' },
  { code:'B5', axis:'B', axisName:'¿Cómo innovar?', group:'Recursos', name:'Funding for Sustainability', meaning:'Estrategias innovadoras de financiación y sostenibilidad financiera de largo plazo.' },
  { code:'B6', axis:'B', axisName:'¿Cómo innovar?', group:'Recursos', name:'Infrastructure/Technology', meaning:'Uso efectivo de tecnología e infraestructura para apoyar investigación, educación, servicio y comercialización.' },
  { code:'B7', axis:'B', axisName:'¿Cómo innovar?', group:'Mecanismos', name:'Cost-Effectiveness Management', meaning:'Eficiencia económica, reducción de costos, generación de ingresos o mejor uso de recursos.' },
  { code:'B8', axis:'B', axisName:'¿Cómo innovar?', group:'Mecanismos', name:'University Brand and Reputation', meaning:'Estrategias creativas para fortalecer marca, reputación, visibilidad, influencia y posición competitiva.' },

  { code:'C1', axis:'C', axisName:'¿Qué innovar?', group:'Investigación', name:'Representative Research Project', meaning:'Proyecto de investigación insignia, sostenido, relevante, con potencial transformador e impacto social.' },
  { code:'C2', axis:'C', axisName:'¿Qué innovar?', group:'Investigación', name:'Interdisciplinary, Convergent, and Integrated Research', meaning:'Investigación interdisciplinaria, convergente e integrada que cruza fronteras disciplinares.' },
  { code:'C3', axis:'C', axisName:'¿Qué innovar?', group:'Educación', name:'Curricular Innovation for Future-Readiness', meaning:'Innovación curricular para habilidades futuras: creatividad, IA, ESG, microcredenciales, aprendizaje práctico.' },
  { code:'C4', axis:'C', axisName:'¿Qué innovar?', group:'Educación', name:'AI-based Teaching and Learning Transformation', meaning:'Uso de IA para transformar enseñanza y aprendizaje: personalización, acceso, automatización y nuevos roles educativos.' },
  { code:'C5', axis:'C', axisName:'¿Qué innovar?', group:'Servicio / transferencia', name:'Social Impact through Knowledge Transfer', meaning:'Transferencia de conocimiento para resolver problemas reales con influencia en políticas, sistemas, comunidades o industrias.' },
  { code:'C6', axis:'C', axisName:'¿Qué innovar?', group:'Servicio / transferencia', name:'Inclusive Social Innovation for the Underserved', meaning:'Innovación social inclusiva dirigida a poblaciones subatendidas, marginadas o vulnerables.' },
  { code:'C7', axis:'C', axisName:'¿Qué innovar?', group:'Comercialización', name:'University-Based Entrepreneurial Projects', meaning:'Emprendimientos, incubación, licenciamiento, inversión o educación emprendedora que convierte ideas en impacto de negocio.' },
  { code:'C8', axis:'C', axisName:'¿Qué innovar?', group:'Comercialización', name:'Financial Impact-Driven Tech Transfer', meaning:'Transferencia tecnológica con retorno financiero sostenible y valor social/ambiental: tecnología para el bien con viabilidad comercial.' }
];

const headers = {
  'content-type': 'application/json; charset=utf-8',
  'cache-control': 'no-store'
};

function safeText(value, max = 12000) {
  return String(value || '').replace(/[\u0000-\u001F\u007F]/g, ' ').trim().slice(0, max);
}

function normalizeScore(n) {
  const x = Number(n);
  if (!Number.isFinite(x)) return 1;
  return Math.max(1, Math.min(5, Math.round(x)));
}

function computeLevel(score) {
  if (score >= 4.5) return 'Transformadora';
  if (score >= 3.8) return 'Muy sólida';
  if (score >= 3.0) return 'Prometedora';
  if (score >= 2.2) return 'Incipiente';
  return 'Débil / requiere rediseño';
}

function extractJson(text) {
  const cleaned = String(text || '').replace(/```json/gi, '```').replace(/```/g, '');
  const first = cleaned.indexOf('{');
  const last = cleaned.lastIndexOf('}');
  if (first === -1 || last === -1 || last <= first) throw new Error('La IA no devolvió un JSON reconocible.');
  return JSON.parse(cleaned.slice(first, last + 1));
}

function repairEvaluation(data) {
  const categoriesByCode = new Map((data.categories || []).map(c => [String(c.code || '').toUpperCase(), c]));
  const repaired = CATEGORIES.map(base => {
    const src = categoriesByCode.get(base.code) || {};
    const scores = src.scores || {};
    const innovativeness = normalizeScore(scores.innovativeness ?? src.innovativeness);
    const implementability = normalizeScore(scores.implementability ?? src.implementability);
    const impact = normalizeScore(scores.impact ?? src.impact);
    const average = Number(((innovativeness + implementability + impact) / 3).toFixed(2));
    return {
      code: base.code,
      axis: base.axis,
      axisName: base.axisName,
      group: base.group,
      name: base.name,
      meaning: base.meaning,
      scores: { innovativeness, implementability, impact },
      average,
      fit: safeText(src.fit || (average >= 4 ? 'Alta' : average >= 3 ? 'Media' : 'Baja'), 40),
      rationale: safeText(src.rationale || 'La idea requiere más evidencia para valorar esta categoría con precisión.', 900),
      evidenceNeeded: safeText(src.evidenceNeeded || 'Definir evidencia, métricas, usuarios beneficiados, costos y resultados esperados.', 700),
      recommendation: safeText(src.recommendation || 'Precisar el alcance y demostrar resultados verificables.', 700)
    };
  });
  const globalScore = Number((repaired.reduce((acc, c) => acc + c.average, 0) / repaired.length).toFixed(2));
  const axes = ['A','B','C'].reduce((acc, axis) => {
    const items = repaired.filter(c => c.axis === axis);
    const score = Number((items.reduce((s, c) => s + c.average, 0) / items.length).toFixed(2));
    acc[axis] = { score, level: computeLevel(score) };
    return acc;
  }, {});
  const sorted = [...repaired].sort((a,b) => b.average - a.average);
  const primary = safeText(data?.submissionGuidance?.primaryCategory || sorted[0].code, 8).toUpperCase();
  return {
    ...data,
    globalScore,
    level: computeLevel(globalScore),
    axes,
    topCategories: sorted.slice(0, 5).map(c => ({ code: c.code, name: c.name, average: c.average, fit: c.fit })),
    weakCategories: sorted.slice(-5).reverse().map(c => ({ code: c.code, name: c.name, average: c.average, fit: c.fit })),
    categories: repaired,
    submissionGuidance: {
      primaryCategory: primary,
      why: safeText(data?.submissionGuidance?.why || 'La categoría principal se eligió por el mayor ajuste entre problema, beneficiario, mecanismo de innovación y evidencia posible.', 900),
      howToStrengthen: safeText(data?.submissionGuidance?.howToStrengthen || 'Fortalecer evidencia, métricas de impacto, sostenibilidad financiera y claridad de beneficiarios.', 900)
    },
    overallDiagnosis: safeText(data.overallDiagnosis || 'Diagnóstico generado con base en las 24 categorías WURI y los criterios de innovatividad, implementabilidad e impacto.', 1400),
    strategicRisks: Array.isArray(data.strategicRisks) ? data.strategicRisks.map(x => safeText(x, 300)).slice(0, 6) : [],
    immediateImprovements: Array.isArray(data.immediateImprovements) ? data.immediateImprovements.map(x => safeText(x, 300)).slice(0, 6) : []
  };
}

function buildPrompt(payload) {
  const categoriesText = CATEGORIES.map(c => `${c.code}. ${c.name} | Eje ${c.axis}: ${c.axisName} | Grupo: ${c.group} | Significado: ${c.meaning}`).join('\n');
  return `
Eres un evaluador senior de innovación, estrategia y educación superior. Evalúa una idea/proyecto usando el marco WURI 2026 de 24 categorías en tres ejes: A ¿Para quién innovar?, B ¿Cómo innovar?, C ¿Qué innovar?.

Criterios por categoría:
1. Innovatividad: novedad del contenido, del proceso o de la forma de resolver el problema.
2. Implementabilidad: factibilidad, claridad operativa, capacidades, costos/beneficios y viabilidad de ejecución.
3. Impacto: alcance e intensidad del efecto esperado o ya demostrado.

No seas complaciente. Evalúa con rigor. Penaliza ideas genéricas, sin evidencia, sin beneficiario claro, sin modelo operativo, sin diferenciación o sin impacto medible. No inventes logros; si falta información, dilo y baja el puntaje correspondiente. Adapta el marco WURI a ideas de negocio/proyectos, no solo a universidades, pero conserva la lógica de las categorías.

Categorías WURI 2026:
${categoriesText}

Datos de la persona/proyecto:
Nombre: ${safeText(payload.participant, 200)}
Organización/curso: ${safeText(payload.organization, 200)}
Título del proyecto: ${safeText(payload.title, 300)}
Sector: ${safeText(payload.sector, 200)}
Tipo: ${safeText(payload.projectType, 200)}
Idea/proyecto:
${safeText(payload.idea, 7000)}

Devuelve SOLO un JSON válido, sin markdown, con esta estructura exacta:
{
  "overallDiagnosis": "diagnóstico ejecutivo de 180 a 260 palabras",
  "strategicRisks": ["riesgo 1", "riesgo 2", "riesgo 3"],
  "immediateImprovements": ["mejora 1", "mejora 2", "mejora 3"],
  "submissionGuidance": {"primaryCategory":"A1", "why":"explicación", "howToStrengthen":"cómo fortalecer para esa categoría"},
  "categories": [
    {
      "code":"A1",
      "scores":{"innovativeness":1,"implementability":1,"impact":1},
      "fit":"Alta/Media/Baja",
      "rationale":"justificación específica frente a la idea",
      "evidenceNeeded":"qué evidencia faltaría para subir el puntaje",
      "recommendation":"recomendación concreta"
    }
  ]
}

Reglas:
- Incluye exactamente las 24 categorías A1-A8, B1-B8, C1-C8.
- Los puntajes son enteros de 1 a 5.
- No uses decimales en los tres criterios.
- Sé concreto, accionable y crítico.
- El JSON debe poder parsearse con JSON.parse().`;
}

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ ok:false, error:'Método no permitido.' }) };
  }

  try {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      return { statusCode: 500, headers, body: JSON.stringify({ ok:false, error:'Falta configurar ANTHROPIC_API_KEY en Netlify > Environment variables con scope Functions.' }) };
    }

    const payload = JSON.parse(event.body || '{}');
    const sessionCode = safeText(payload.sessionCode || 'GENERAL', 40).toUpperCase().replace(/[^A-Z0-9_-]/g, '') || 'GENERAL';
    const idea = safeText(payload.idea, 7000);
    if (idea.length < 120) {
      return { statusCode: 400, headers, body: JSON.stringify({ ok:false, error:'La descripción de la idea es muy corta. Escribe al menos 120 caracteres con problema, beneficiario, solución, diferencia e impacto esperado.' }) };
    }

    const requestBody = {
      model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6',
      max_tokens: 9000,
      output_config: { effort: process.env.CLAUDE_EFFORT || 'low' },
      system: 'Responde únicamente JSON válido. No incluyas pensamiento interno, markdown ni texto adicional.',
      messages: [
        { role: 'user', content: buildPrompt(payload) }
      ]
    };

    const anthropicRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(requestBody)
    });

    const raw = await anthropicRes.text();
    if (!anthropicRes.ok) {
      let detail = raw;
      try { detail = JSON.parse(raw)?.error?.message || raw; } catch (_) {}
      return { statusCode: anthropicRes.status, headers, body: JSON.stringify({ ok:false, error:'Error de Anthropic API', detail }) };
    }

    const anth = JSON.parse(raw);
    const text = (anth.content || []).filter(x => x.type === 'text').map(x => x.text).join('\n').trim();
    const parsed = extractJson(text);
    const evaluation = repairEvaluation(parsed);

    const id = `${sessionCode}:${Date.now()}:${Math.random().toString(36).slice(2, 9)}`;
    const record = {
      id,
      sessionCode,
      createdAt: new Date().toISOString(),
      participant: safeText(payload.participant || 'Sin nombre', 200),
      organization: safeText(payload.organization, 200),
      title: safeText(payload.title || 'Idea sin título', 300),
      sector: safeText(payload.sector, 200),
      projectType: safeText(payload.projectType, 200),
      idea,
      evaluation,
      usage: anth.usage || null,
      model: requestBody.model
    };

    try {
      const store = getStore('wuri-ai-evaluations');
      await store.setJSON(id, record);
    } catch (storageError) {
      record.storageWarning = `La evaluación se generó, pero no se pudo guardar en dashboard: ${storageError.message}`;
    }

    return { statusCode: 200, headers, body: JSON.stringify({ ok:true, record }) };
  } catch (error) {
    return { statusCode: 500, headers, body: JSON.stringify({ ok:false, error:error.message || 'Error inesperado.' }) };
  }
};
