const headers = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };
export const handler = async () => {
  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      ok: true,
      service: 'wuri-ai-evaluator',
      hasAnthropicKey: Boolean(process.env.ANTHROPIC_API_KEY),
      model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6',
      hasAdminPin: Boolean(process.env.ADMIN_PIN),
      now: new Date().toISOString()
    })
  };
};
